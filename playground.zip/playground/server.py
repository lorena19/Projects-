from flask import Flask, render_template
app = Flask(__name__) 

@app.route('/')
def welcome():
    return "Welcome"

@app.route('/play')          # The "@" decorator associates this route with the function immediately following
def main():
    return render_template("index.html")

@app.route('/play/<int:num>')
def display(num):
    return render_template("playtimes.html", num=num)

@app.route('/play/<int:num>/<color>')
def change_color(num, color):
    return render_template("colortimes.html", num=num, color=color)





if __name__=="__main__":
    app.run(debug=True)