from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def main():
    return render_template("checker.html", rows=8, columns=8)

@app.route('/<int:y>')
def oneDimensions(y):
    return render_template("checker.html")

@app.route('/<int:x>/<int:y>')
def twoDimensions(x,y):
    return render_template("checker.html", rows=x, columns=y)


if __name__ == "___main___":
    app.run(debug=True)