from django.apps import AppConfig


class DojoNinjasApp2Config(AppConfig):
    name = 'dojo_ninjas_app2'
