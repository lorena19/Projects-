using System.ComponentModel.DataAnnotations; 
using System; 

namespace Exam.Validations
{
    public class FutureAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if((DateTime)value < DateTime.Now)
            {
                return new ValidationResult("Activity must be in the future");
            }
            return ValidationResult.Success; 
        }
    }
}