﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Exam.Models;
using Exam.Contexts; 
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace Exam.Controllers
{
    public class HomeController : Controller
    {
        private MyContext dbContext; 

        public HomeController(MyContext context)
        {
            dbContext = context; 
        }

        public User UserInDb()
        {
            return dbContext.Users.FirstOrDefault(u => u.UserId == HttpContext.Session.GetInt32("UserId"));
        }


        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("register")]
        public IActionResult Register(User reg)
        {
            if(ModelState.IsValid)
            {
                if(dbContext.Users.Any(u => u.Email == reg.Email))
                {
                    ModelState.AddModelError("Email", "Email already in use");
                    return View("Index"); 
                }
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                reg.Password = Hasher.HashPassword(reg, reg.Password);
                dbContext.Users.Add(reg); 
                dbContext.SaveChanges(); 
                HttpContext.Session.SetInt32("UserId", reg.UserId);

                return RedirectToAction("Success"); 
            }
            else
            {
                return View("Index"); 
            }
        }

        [HttpPost("login")]
        public IActionResult Login(LoginUser log)
        {
            if(ModelState.IsValid)
            {
                var userInDb = dbContext.Users.FirstOrDefault(u => u.Email == log.LoginEmail); //query user based on email
                if(userInDb == null)
                {
                    ModelState.AddModelError("LoginEmail", "Invalid Email/Password");
                    ModelState.AddModelError("LoginPassword", "Invalid Email/Password");
                    return View("Index");
                }
                //These two lines will compare our hashed passwords.
                var hash = new PasswordHasher<LoginUser>();
                var result = hash.VerifyHashedPassword(log, userInDb.Password, log.LoginPassword);
                //Result will either be 0 or 1.
                if(result == 0)
                {
                    ModelState.AddModelError("LoginEmail", "Invalid Email/Password");
                    ModelState.AddModelError("LoginPassword", "Invalid Email/Password");
                    return View("Index");
                }
                HttpContext.Session.SetInt32("UserId", userInDb.UserId); //put UserId in Session.

                return Redirect("Success");  //redirecting
            }
                else 
                {
                    return View("Index"); 
                }

            }


        [HttpGet("success")]
        public IActionResult Success()
        {
            User userInDb = UserInDb(); 
            if(userInDb == null)
            {
                return RedirectToAction("Logout");
            }
            ViewBag.User = userInDb;
            List<Games> AllGames = dbContext.Games
                                    .Include(u => u.EventCoordinator)
                                    .Include(u => u.EventList)
                                    .ThenInclude(r => r.Participants)
                                    .ToList();
            return View(AllGames); 
        }

        [HttpGet("new/game")]
        public IActionResult NewGame()
        {
            User userInDb = UserInDb(); 
            if(userInDb == null)
            {
                return RedirectToAction("Logout");
            }
            ViewBag.User = userInDb; 
            return View(); 
        }

        [HttpPost("create/game")]
        public IActionResult CreateGame(Games plan)
        {
            User userInDb = UserInDb(); 
            if(userInDb == null)
            {
                return RedirectToAction("Logout");
            }
            if(ModelState.IsValid)
            {
                dbContext.Games.Add(plan);
                dbContext.SaveChanges(); 
                return Redirect($"/show/{plan.GameId}"); //always redirect to the same page first to tes if every works

            }
            else
            {
                ViewBag.User = userInDb; 
                return View("NewGame"); 
            }
        }

        [HttpGet("show/{gameId}")]
        public IActionResult ShowGame(int gameId)
        {
            User userInDb = UserInDb(); 
            if(userInDb == null)
            {
                return RedirectToAction("Logout");
            } 

            Games show = dbContext.Games
                            .Include( u => u.EventCoordinator)
                            .Include( u => u.EventList)
                            .ThenInclude( r => r.Participants)
                            .FirstOrDefault( u => u.GameId == gameId); 
            ViewBag.User = userInDb; 
            return View(show); 
        }

        [HttpGet("{status}/{gameId}/{userId}")]
        public IActionResult Confirm(string status, int gameId, int userId)
        {
            User userInDb = UserInDb(); 
            if(userInDb == null)
            {
                return RedirectToAction("Logout");
            } 
            if(status =="join")
            {
                Actions going = new Actions(); 
                going.UserId = userId;
                going.GameId = gameId; 
                dbContext.Actions.Add(going); 
                dbContext.SaveChanges();      
            }
            else if(status =="leave")
            {
                Actions leave = dbContext.Actions.FirstOrDefault(r => r.GameId == gameId && r.UserId == userId);
                dbContext.Actions.Remove(leave); 
                dbContext.SaveChanges();
            }
            return RedirectToAction("Success"); 
        }



        [HttpGet("delete/{gameId}")]
        public IActionResult Remove(int gameId)
            {
                User userInDb = UserInDb(); 
                if(userInDb == null)
                {
                    return RedirectToAction("Logout");
                } 
                Games cancel = dbContext.Games.FirstOrDefault(u => u.GameId == gameId);
                dbContext.Games.Remove(cancel); 
                dbContext.SaveChanges(); 
                return RedirectToAction("Success"); 
            }



        [HttpGet("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index"); 
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
