using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; 
using System.ComponentModel.DataAnnotations.Schema;

namespace Exam.Models
{
    public class User
    {
        [Key]
        public int UserId {get; set;}

        [Required(ErrorMessage="Name is required")]
        [MinLength(2, ErrorMessage="name must be at least 2 characters.")]
        [Display(Name="Name:")]
        public string Name {get; set;}

        [EmailAddress]
        [Required(ErrorMessage="must be a valid email")]
        public string Email {get; set;}

        [DataType(DataType.Password)]
        [Required]
        [MinLength(8, ErrorMessage="Password must be 8 characters or longer!")]
        public string Password {get;set;}

        public DateTime CreatedAt {get;set;} = DateTime.Now;
        public DateTime UpdatedAt {get;set;} = DateTime.Now;
        // Will not be mapped to your users table!
        [NotMapped]
        [Compare("Password")]
        [DataType(DataType.Password)]
        public string Confirm {get;set;}

        //one to many - a user can plan many games
        public List<Games> MyGames {get; set;}

        //many to many - a user can go to many activity events.
        public List<Actions> Going {get; set;}
    }
}