using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; 
using Exam.Validations; 


namespace Exam.Models
{
    public class Games
    {
        [Key]
        public int GameId {get; set;}

        [Required]
        public string Title {get; set;}
        
        [Required(ErrorMessage="Activity Date is required")]
        [Future]
        [Display(Name="DATE and START Time:")]
        public DateTime Date {get; set; }

        [Required]
        public string Description {get; set;}

        [Required]
        public int Duration {get; set;}

        //One to Many Foreign Key
        public int UserId {get; set;}

        //one to many, a user can plan many activites
        public User EventCoordinator {get; set;}

        //nav for many to many - a Event can have many participants
        public List<Actions> EventList {get; set;}

        public DateTime CreatedAt {get; set;} = DateTime.Now; 

        public DateTime UpdatedAt {get; set;} = DateTime.Now; 

    }
}