using System.ComponentModel.DataAnnotations;

namespace Exam.Models
{
    public class Actions
    {
        [Key]
        public int ActionId {get; set;}

        public int UserId {get; set;}

        public int GameId {get; set;}

        //nav properties

        public User Participants {get; set;}

        public Games Attending {get; set;}
    }
}