using System.ComponentModel.DataAnnotations; 

namespace Exam.Models
{
    public class LoginUser
    {
        [Required]
        [EmailAddress]
        [Display(Name="Email:")]
        public string LoginEmail {get; set;}


        [DataType(DataType.Password)]
        [MinLength(8, ErrorMessage="Password must be at least 8 characters long")]
        [Required]
        [Display(Name="Password:")]
        public string LoginPassword {get;set;}
    }
}