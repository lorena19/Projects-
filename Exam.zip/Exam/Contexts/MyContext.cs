using Microsoft.EntityFrameworkCore;
using Exam.Models; 

namespace Exam.Contexts
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions options) : base(options) { }

        public DbSet<User> Users {get; set;}
        public DbSet<Games> Games {get; set;}
        public DbSet<Actions> Actions {get; set;}
    }
}