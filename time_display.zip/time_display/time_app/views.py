from django.shortcuts import render, HttpResponse
from time import localtime, strftime

def root_method(request):
    clock = {
        "time": strftime("%b %d, %Y %I:%M %p", localtime())
        
    }

    return render(request, 'index.html', clock)